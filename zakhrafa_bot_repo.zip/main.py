import os
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

def decorate_name(name: str) -> str:
    styles = [
        f"★ {name} ★",
        f"『 {name} 』",
        f"♛ {name} ♛",
        f"𓆩 {name} 𓆪",
        f"꧁ {name} ꧂",
        f"✧ {name} ✧"
    ]
    return "\n".join(styles)

def save_user(user_id: int):
    if not os.path.exists("users.txt"):
        with open("users.txt", "w") as f:
            pass
    with open("users.txt", "r") as f:
        users = f.read().splitlines()
    if str(user_id) not in users:
        with open("users.txt", "a") as f:
            f.write(str(user_id) + "\n")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    save_user(user_id)

    if user_id == ADMIN_ID:
        keyboard = [["📊 عدد المشتركين", "📣 رسالة جماعية"], ["🔁 إعادة تشغيل"]]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("👑 مرحبًا بك في لوحة تحكم البوت", reply_markup=reply_markup)
    else:
        await update.message.reply_text("مرحبًا بك! أرسل اسمك وسأزخرفه لك ✨")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text

    if user_id == ADMIN_ID:
        if text == "📊 عدد المشتركين":
            if not os.path.exists("users.txt"):
                await update.message.reply_text("لا يوجد مشتركين بعد.")
            else:
                with open("users.txt") as f:
                    users = f.read().splitlines()
                await update.message.reply_text(f"📊 عدد المشتركين: {len(users)}")

        elif text == "📣 رسالة جماعية":
            await update.message.reply_text("✍️ أرسل الآن الرسالة التي تريد إرسالها لجميع المشتركين.")
            context.user_data["broadcast"] = True

        elif text == "🔁 إعادة تشغيل":
            await update.message.reply_text("♻️ يتم الآن إعادة تشغيل البوت...")
            os.execl(sys.executable, sys.executable, *sys.argv)

        elif context.user_data.get("broadcast"):
            if not os.path.exists("users.txt"):
                await update.message.reply_text("⚠️ لا يوجد مشتركين لإرسال الرسالة.")
            else:
                with open("users.txt") as f:
                    users = f.read().splitlines()
                count = 0
                for uid in users:
                    try:
                        await context.bot.send_message(chat_id=int(uid), text=text)
                        count += 1
                    except:
                        pass
                await update.message.reply_text(f"✅ تم إرسال الرسالة إلى {count} مستخدم.")
            context.user_data["broadcast"] = False

    else:
        decorated = decorate_name(text.strip())
        await update.message.reply_text(f"✨ تم الزخرفة:\n\n{decorated}")

if __name__ == "__main__":
    import sys
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("✅ Bot is running...")
    app.run_polling()
